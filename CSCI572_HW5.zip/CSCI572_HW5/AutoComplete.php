<?php
	if($_POST["query"]){
		autocomplete(strtolower($_POST["query"]));
	}
	function autocomplete($query){
		$suggestwords = [];
		if($query){
					require_once("solr-php-client-master/Apache/Solr/Service.php");

					$solr = new Apache_Solr_Service('localhost',8983,'/solr/mycs572/');

					try{
							$autocomplete = $solr->suggest($query);
							$i = 0;
							foreach ($autocomplete->suggest->suggest->$query->suggestions as $suggestion){
									if($suggestion->term != $query && $i < 5){
										$i++;
										array_push($suggestwords,$suggestion->term);
									}
							}
					}
					catch(Exception $e){
						die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
					}
				}
		echo json_encode($suggestwords);

	}
				
?>