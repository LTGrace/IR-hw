I made some changes in Service.php in "solr-php-client-master" folder.
I use simple_html_dom.php to get the text content from html