<?php

ini_set('memory_limit','1024M');
include 'SpellCorrector.php';
include "simple_html_dom.php";

header('Content-Type:text/html;charset=utf-8');

$limit = 10;
$query = isset($_REQUEST['q'])?$_REQUEST['q']:false;
$correctquery="";
if($query){
	if(get_magic_quotes_gpc() == 1){

		$query = stripslashes($query);
		
	}

	$tempquery = explode(" ", $query);
	$num = count($tempquery);


	for($i = 0; $i < $num; $i++){
		$tempquery[$i] = SpellCorrector::correct($tempquery[$i]);
	}
	$correctquery = implode(" ", $tempquery);
}
$results = false;
$additionalParameters = array(
'sort' => 'pageRankFile desc'
);
//$pageRank = false;
if(!empty($_GET['pageRank'])){
	$pageRank = true;
}
?>

<html>
	<head>
		<title>PHP Solr Client Example</title>
		<style type="text/css">
		a:link {
			color: blue;
			text-decoration: none;
		}
		a:hover{
			text-decoration: underline;
		}
		a:visited{
			color: blue;
		}
		</style>

		<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  		<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

		<script>
			$(document).ready(function(){
				$("#q").autocomplete({
					source:function(request,response){
						var before = "";
						var current = "";
						if(request.term.indexOf(" ") == -1){
							current = request.term;
						}else{
							var temp = request.term.split(" ");
							for(var i = 0; i < temp.length-1; i++){
								before = before +temp[i]+ " ";
							}
							current = temp[temp.length-1];
						}
						$.ajax({
							type:"POST",
							url:"Autocomplete.php",
							data:{"query":current},
							dataType:"json",
							success:function(data){
								for(var i = 0; i < data.length; i++){
									data[i] = before + data[i];
								}
								response(data);
							}
						});
					}
				})
		  	}) 
  		</script>
	</head>

	
	<body>
		<form accept-charset="utf-8" method="get">
			<label for = "q" style="font-size: 25px;font-family: Comic Sans MS, cursive, sans-serif">Search:</label>
			<input id = "q" name = "q" type="text" autocomplete="off" value = "<?php echo htmlspecialchars($query, ENT_QUOTES, 'utf-8'); ?>" />
			<input type="submit" name="Lucene" value="Lucene"/>
			<!--<input type="submit" name="pageRank" value="pageRank"/> -->
		</form>
		<div style="display: <?php if(!isset($_REQUEST['q']) || $correctquery == $query) echo "none";?>;font-size:18px;">
			<p>Search instead for
				<strong style="font-size: 15px;">
					<a href="search.php?q=<?php echo $correctquery?>&Lucene=Lucene" id="correct">
						<?php
							echo $correctquery;
						?>
					</a>
				</strong>
			</p>
		</div>

<?php

if($query){
	require_once("solr-php-client-master/Apache/Solr/Service.php");

	$solr = new Apache_Solr_Service('localhost',8983,'/solr/mycs572/');

	try{

			$results = $solr->search($query,0,$limit);
			//complete($query);
			
	}
	catch(Exception $e){
		die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
	}
}

if($results){
	$total = (int)$results->response->numFound;
	$start = min(1,$total);
	$end = min($limit,$total);


?>

<div>Results <?php echo $start; ?> - <?php echo $end;?> of <?php echo $total; ?>:</div>
<ol>
	<?php
		foreach($results->response->docs as $doc){
			$data = array();
	?>	
		<li style="margin-bottom: 5px">
			<table style="border: 0px solid black; text-align: left">
	<?php
		foreach($doc as $field => $value){
			$has_og_url = false;
			
			if($field == "id" || $field == "title" || $field == "og_url" || $field == "description"){
				$data[$field] = $value;	
			}
		}
		if(!array_key_exists("og_url",$data)){
			$file = fopen("URLtoHTML_mercury.csv", "r");
			$line = fgets($file);
			$temp = explode("/", $data["id"]);
			$temp_size = count($temp);
			while(!feof($file)){
				$line = explode(',', fgets($file));
				if($line[0] == $temp[$temp_size-1]){
					$data["og_url"] = $line[1];
					break;
				}
			}
			
			fclose($file);
		}
		if(!array_key_exists("description", $data)){
			$data["description"] = "N/A";
		}
	?>	
	
	
		<tr>
			<th><?php echo htmlspecialchars("id:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><?php echo htmlspecialchars($data["id"], ENT_NOQUOTES, 'utf-8'); ?></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("title:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><a href='<?php echo $data['og_url'] ?>'><?php echo $data['title']?></a></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("url:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><a href='<?php echo $data["og_url"] ?>'><?php echo $data['og_url']?></a></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("snippet:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td>
				<?php 
					 $text = file_get_html($data["og_url"])->plaintext;
					 $text_array = preg_split("/[;,.!?\s]/", $text);
					 $query_array = preg_split("/[;,.!?\s]/", $query);
					 $is_exist = false;
					 $result_snippet=[];
					 for($j = 0; $j < count($query_array);$j++){
					 	$index = $j;
					 	$total_length = 0;
					 	$flag = false;
					 	$match_words = 0;
					 	for($i = 0; $i < count($text_array);$i++){
						 	if($index < count($query_array) && strtolower($text_array[$i]) == strtolower($query_array[$index])){
						 		$flag = true;
						 		$match_words++;
						 		$index++;
						 	}
						 	if($flag){
						 		if($total_length >= 160) 
						 			break;
						 		$total_length += strlen($text_array[$i]);
						 		array_push($result_snippet, $text_array[$i]);
						 	}
					 	}
						if($match_words > 0){
						 	$is_exist = true;
						 	break;
						}
					 }
					 if($is_exist){
					 	$res = implode(" ", $result_snippet);
						$res = $res."...";
					 	echo $res; 
					 }
					 else 
					 	echo "no matched text found!";	 	
				?>	
			</td>
		</tr>
	
			</table>
		</li>
		<hr>
	<?php
		}
	?>
</ol>
<?php
}
?>


	</body>
	</html>
