import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
public class InvertedIndex {
	 public static class TokenizerMapper
     extends Mapper<Object, Text, Text, Text>{

  public void map(Object key, Text value, Context context
                  ) throws IOException, InterruptedException {
	  InputSplit inputSplit = context.getInputSplit();
	  String fileName = ((FileSplit) inputSplit).getPath().getName();
	  fileName = fileName.split("\\.")[0];
	  Text documentId = new Text(fileName);
      StringTokenizer itr = new StringTokenizer(value.toString().toLowerCase().replaceAll("[^a-z]", " "));
	  while (itr.hasMoreTokens()) {
		      String temp = itr.nextToken();
		      if(!temp.isEmpty())
		    	  context.write(new Text(temp), documentId);
	  }
  }
}

public static class SumReducer
     extends Reducer<Text,Text,Text,Text> {
  public void reduce(Text key, Iterable<Text> values,
                     Context context
                     ) throws IOException, InterruptedException {
      Map<String,Integer> map = new HashMap<>();
      Iterator<Text> it = values.iterator();
      while(it.hasNext()) {
    	  String tmp = it.next().toString();
    	  if(map.containsKey(tmp)) {
    		  map.put(tmp, map.get(tmp)+1);
    	  }else {
    		  map.put(tmp, 1);
    	  }
      }
      StringBuilder res = new StringBuilder();
      for(String tmp:map.keySet()){
    	  res.append(tmp+":"+map.get(tmp)+" ");
      }
      context.write(key, new Text(res.toString())); 
  }
}

public static void main(String[] args) throws Exception {
  Configuration conf = new Configuration();
  Job job = Job.getInstance(conf, "Inverted Index");
  job.setJarByClass(InvertedIndex.class);
  job.setMapperClass(TokenizerMapper.class);
  job.setReducerClass(SumReducer.class);
  job.setOutputKeyClass(Text.class);
  job.setOutputValueClass(Text.class);
  FileInputFormat.addInputPath(job, new Path(args[0]));
  FileOutputFormat.setOutputPath(job, new Path(args[1]));
  System.exit(job.waitForCompletion(true) ? 0 : 1);
}
}
