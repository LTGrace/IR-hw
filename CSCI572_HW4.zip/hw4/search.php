<?php
header('Content-Type:text/html;charset=utf-8');

$limit = 10;
$query = isset($_REQUEST['q'])?$_REQUEST['q']:false;
$results = false;
$additionalParameters = array(
'sort' => 'pageRankFile desc'
);
$pageRank = false;
if(!empty($_GET['pageRank'])){
	$pageRank = true;
}
?>

<html>
	<head>
		<title>PHP Solr Client Example</title>
	</head>
	<body>
		<form accept-charset="utf-8" method="get">
			<label for = "q">Search:</label>
			<input id = "q" name = "q" type="text" value = "<?php echo htmlspecialchars($query, ENT_QUOTES, 'utf-8'); ?>" />
			<input type="submit" name="Lucene" value="Lucene"/>
			<input type="submit" name="pageRank" value="pageRank"/>
		</form>

<?php

if($query){
	require_once("solr-php-client-master/Apache/Solr/Service.php");


	$solr = new Apache_Solr_Service('localhost',8983,'/solr/mycs572/');

	if(get_magic_quotes_gpc() == 1){

		$query = stripslashes($query);
	}

	try{
		if($pageRank)
			$results = $solr->search($query,0,$limit,$additionalParameters);
		else
			$results = $solr->search($query,0,$limit);
	}
	catch(Exception $e){
		die("<html><head><title>SEARCH EXCEPTION</title><body><pre>{$e->__toString()}</pre></body></html>");
	}
}

if($results){
	$total = (int)$results->response->numFound;
	$start = min(1,$total);
	$end = min($limit,$total);


?>

<div>Results <?php echo $start; ?> - <?php echo $end;?> of <?php echo $total; ?>:</div>
<ol>
	<?php
		foreach($results->response->docs as $doc){
			$data = array();
	?>	
		<li style="margin-bottom: 5px">
			<table style="border: 0px solid black; text-align: left">
	<?php
		foreach($doc as $field => $value){
			$has_og_url = false;
			
			if($field == "id" || $field == "title" || $field == "og_url" || $field == "description"){
				$data[$field] = $value;	
			}
		}
		if(!array_key_exists("og_url",$data)){
			$file = fopen("URLtoHTML_mercury.csv", "r");
			$line = fgets($file);
			$temp = explode("/", $data["id"]);
			$temp_size = count($temp);
			while(!feof($file)){
				$line = explode(',', fgets($file));
				// echo $line[0];
				// echo "=========maomao====\n";
				// echo "+";
				// echo $temp[$temp_size-1];
				if($line[0] == $temp[$temp_size-1]){
					$data["og_url"] = $line[1];
					break;
				}
			}
			
			fclose($file);
		}
		if(!array_key_exists("description", $data)){
			$data["description"] = "N/A";
		}
	?>	
	
	
		<tr>
			<th><?php echo htmlspecialchars("id:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><?php echo htmlspecialchars($data["id"], ENT_NOQUOTES, 'utf-8'); ?></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("title:", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><a href='<?php echo $data['og_url'] ?>'><?php echo $data['title']?></a></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("url", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><a href='<?php echo $data["og_url"] ?>'><?php echo $data['og_url']?></a></td>
		</tr>
		<tr>
			<th><?php echo htmlspecialchars("description", ENT_NOQUOTES, 'utf-8'); ?></th> 
			<td><?php echo htmlspecialchars($data["description"], ENT_NOQUOTES, 'utf-8'); ?></td>
		</tr>
	
			</table>
		</li>
		<hr>
	<?php
		}
	?>
</ol>
<?php
}
?>

	</body>
	</html>
